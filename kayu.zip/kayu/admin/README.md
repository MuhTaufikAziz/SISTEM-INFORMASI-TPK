<h1 align="left">ONLINE SHOP</h1>
<h3 align="left">Website using PHP CSS HTML MySQL</h3>
<h4 align="left">Desain website terinspirasi dari berbagai website sederhana dan referensi youtube></h4>

<h2 align="left">Halaman Pilihan Login</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737222-ce19adaa-d612-453d-bbc7-41e6d3963499.png" />

<h2 align="left">Halaman Login</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737272-9e249da2-8a0b-41a9-bb56-d84e4629d695.png" />

<h2 align="left">Halaman Create New Account</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737483-81b5eca9-3991-42b3-ade3-5210fd6ccb5f.png" />

<h2 align="left">Halaman Dashboard</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737751-2e4ed788-9f7c-442d-ad14-136a58f19427.png" />

<h2 align="left">CRUD Produk</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737804-ec54c41a-a566-4164-8305-d7e640f23ddb.png" />

<h2 align="left">Beli Produk</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737838-db99d323-f9b4-4823-b08e-70d9bb8cf1c0.png" />

<h2 align="left">Keranjang Pembelian</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737877-e1f276aa-63e1-4a88-986a-4bf2c67e80d4.png" />

<h2 align="left">Data Transaksi</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737902-05cf144f-b714-463f-aeee-4682818fa724.png" />

<h2 align="left">Struk Transaksi</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737912-c44365e2-506d-4fb6-84c4-d4f656192894.png" />

<h2 align="left">CRUD User</h2>
<img src="https://user-images.githubusercontent.com/71278187/153737934-7cd3d46d-cb37-4cec-8f6f-fbe1f0d795e5.png" />

<h3 align="center">Languages and Tools :</h3>
<p align="center"> 
<a href="https://www.php.net" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/php/php-original.svg" alt="php" width="40" height="40"/> </a> 
<a href="https://www.w3schools.com/css/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> 
<a href="https://www.w3.org/html/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a>
<a href="https://www.mysql.com/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/mysql/mysql-original-wordmark.svg" alt="mysql" width="40" height="40"/> </a> 
</p>
